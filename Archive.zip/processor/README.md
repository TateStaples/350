# Processor
## NAME (NETID)
Tate Staples (jts98)
## Description of Design

## Bypassing

## Stalling

## Optimizations

## Bugs
